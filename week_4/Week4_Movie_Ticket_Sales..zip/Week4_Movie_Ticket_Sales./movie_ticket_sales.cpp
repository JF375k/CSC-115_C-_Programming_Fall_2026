#include <iostream>
#include <iomanip>
using namespace std;

int main()
{
    // Variables
    int customers, tickets, category;
    int childTickets, adultTickets, seniorTickets;
    int totalTickets;

    double price, total, totalRevenue, average;
    char again = 'Y';

    cout << fixed << setprecision(2);

    while (again == 'Y' || again == 'y')
    {
        childTickets = 0;
        adultTickets = 0;
        seniorTickets = 0;
        totalTickets = 0;
        totalRevenue = 0.0;

        cout << "\nMovie Theater Ticket Sales" << endl;
        cout << "--------------------------" << endl;

        cout << "Enter number of customers (1-50): ";
        cin >> customers;

        while (customers < 1 || customers > 50)
        {
            cout << "Invalid number. Enter 1-50: ";
            cin >> customers;
        }

        for (int count = 1; count <= customers; count++)
        {
            cout << "\nCustomer " << count << endl;
            cout << "--------------------------" << endl;

            // Get the number of tickets
            cout << "How many tickets (1-10)? ";
            cin >> tickets;

            while (tickets < 1 || tickets > 10)
            {
                cout << "Invalid number. Enter 1-10: ";
                cin >> tickets;
            }

            // Display ticket categories
            cout << "\nSelect Ticket Category" << endl;
            cout << "1. Child - $8.00" << endl;
            cout << "2. Adult - $12.00" << endl;
            cout << "3. Senior - $9.00" << endl;

            cout << "Enter your selection: ";
            cin >> category;

            while (category < 1 || category > 3)
            {
                cout << "Invalid selection. Enter 1, 2, or 3: ";
                cin >> category;
            }

            // Determine the ticket price
            if (category == 1)
            {
                price = 8.00;
                childTickets += tickets;
            }
            else if (category == 2)
            {
                price = 12.00;
                adultTickets += tickets;
            }
            else
            {
                price = 9.00;
                seniorTickets += tickets;
            }

            total = tickets * price;

            totalTickets += tickets;
            totalRevenue += total;

            cout << "\nTickets Purchased: " << tickets << endl;

            if (category == 1)
            {
                cout << "Ticket Category: Child" << endl;
            }
            else if (category == 2)
            {
                cout << "Ticket Category: Adult" << endl;
            }
            else
            {
                cout << "Ticket Category: Senior" << endl;
            }

            cout << "Price Per Ticket: $" << price << endl;
            cout << "Transaction Total: $" << total << endl;
        }

        average = totalRevenue / customers;

        cout << "\n========================================" << endl;
        cout << "       MOVIE THEATER SALES REPORT" << endl;
        cout << "========================================" << endl;

        cout << "Customers Processed: " << customers << endl;
        cout << "Child Tickets Sold: " << childTickets << endl;
        cout << "Adult Tickets Sold: " << adultTickets << endl;
        cout << "Senior Tickets Sold: " << seniorTickets << endl;
        cout << "Total Tickets Sold: " << totalTickets << endl;
        cout << "Total Revenue: $" << totalRevenue << endl;
        cout << "Average Transaction: $" << average << endl;

        cout << "========================================" << endl;

        cout << "\nWould you like to process another sales session?" << endl;
        cout << "Enter Y for Yes or N for No: ";
        cin >> again;

        while (again != 'Y' && again != 'y' &&
               again != 'N' && again != 'n')
        {
            cout << "Invalid choice. Enter Y or N: ";
            cin >> again;
        }
    }

    cout << "\nThank you for using the program!" << endl;

    return 0;
}